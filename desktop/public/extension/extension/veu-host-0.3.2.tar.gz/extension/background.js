/**
 * Véu Host 0.3.2 — service worker + Native Messaging (com.veu.host).
 */

const VERSION = "0.3.2";
const NATIVE_HOST = "com.veu.host";

const WEB_APPS = {
  whatsapp: "https://web.whatsapp.com/",
  gmail: "https://mail.google.com/",
  notion: "https://www.notion.so/",
  teams: "https://teams.microsoft.com/",
  outlook: "https://outlook.office.com/",
  slack: "https://app.slack.com/",
};

function sendNative(msg, timeoutMs = 6000) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (value) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      resolve(value);
    };
    const timer = setTimeout(() => {
      finish({ ok: false, error: "timeout native host", native: false });
    }, timeoutMs);

    try {
      chrome.runtime.sendNativeMessage(NATIVE_HOST, msg, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          finish({
            ok: false,
            error: err.message || String(err),
            native: false,
          });
          return;
        }
        finish({ ...(response || { ok: false, error: "sem resposta" }), native: true });
      });
    } catch (e) {
      finish({ ok: false, error: String(e), native: false });
    }
  });
}

chrome.runtime.onInstalled.addListener(() => {
  console.info(`[Véu Host ${VERSION}] instalada · native=${NATIVE_HOST}`);
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || !msg.type) {
    sendResponse({ ok: false, error: "mensagem inválida" });
    return false;
  }

  (async () => {
    if (msg.type === "veu.host.info" || msg.type === "veu.ping") {
      const native = await sendNative({ type: "veu.host.info" }, 2500);
      sendResponse({
        ok: true,
        data: {
          version: VERSION,
          extensionId: chrome.runtime.id,
          nativeHost: NATIVE_HOST,
          nativeConnected: !!(native && native.ok && native.native),
          nativeError: native && !native.ok ? native.error : undefined,
          nativeData: native && native.ok ? native.data : undefined,
          note: native && native.ok
            ? "extensão + Native Messaging ok"
            : "extensão ok — instale o host nativo para terminal/shell",
        },
      });
      return;
    }

    if (msg.type === "veu.host.openApp") {
      const native = await sendNative({
        type: "veu.host.openApp",
        app: msg.app,
      });
      if (native && native.ok) {
        sendResponse(native);
        return;
      }

      const url = WEB_APPS[msg.app];
      if (url) {
        await chrome.tabs.create({ url });
        sendResponse({
          ok: true,
          data: {
            opened: url,
            mode: "web-fallback",
            nativeError: native && native.error,
          },
        });
        return;
      }

      sendResponse({
        ok: false,
        error:
          (native && native.error
            ? `Native: ${native.error}. `
            : "") +
          `App "${msg.app}" precisa do host nativo. ` +
          `Instale: /extension/native/ (ID ${chrome.runtime.id})`,
        data: {
          extensionId: chrome.runtime.id,
          nativeHost: NATIVE_HOST,
          install: "https://veu.ch8ai.com.br/extension/#native",
        },
      });
      return;
    }

    if (
      msg.type === "veu.host.shell" ||
      msg.type === "veu.host.readPath" ||
      msg.type === "veu.host.listDir"
    ) {
      const native = await sendNative(msg);
      sendResponse(
        native && native.ok
          ? native
          : {
              ok: false,
              error:
                (native && native.error) ||
                "Host nativo ausente. Rode install.sh / install.ps1 em /extension/native/",
              data: { extensionId: chrome.runtime.id },
            },
      );
      return;
    }

    sendResponse({ ok: false, error: `tipo não suportado: ${msg.type}` });
  })();

  return true;
});
