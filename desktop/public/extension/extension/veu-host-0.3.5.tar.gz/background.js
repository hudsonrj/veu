/**
 * Véu Host 0.3.5 — service worker + Native Messaging (com.veu.host).
 * Abre apps, foca abas, lê inbox/mensagens em programas abertos no browser.
 */

const VERSION = "0.3.5";
const NATIVE_HOST = "com.veu.host";

const WEB_APPS = {
  whatsapp: "https://web.whatsapp.com/",
  gmail: "https://mail.google.com/",
  calendar: "https://calendar.google.com/",
  agenda: "https://calendar.google.com/",
  notion: "https://www.notion.so/",
  teams: "https://teams.microsoft.com/",
  outlook: "https://outlook.office.com/",
  slack: "https://app.slack.com/",
  grok: "https://grok.x.ai/",
  chatgpt: "https://chatgpt.com/",
};

const APP_HOST_MATCH = {
  gmail: ["mail.google.com"],
  calendar: ["calendar.google.com"],
  agenda: ["calendar.google.com"],
  notion: ["notion.so", "www.notion.so"],
  slack: ["app.slack.com"],
  outlook: ["outlook.office.com", "outlook.live.com"],
  teams: ["teams.microsoft.com", "teams.live.com"],
  whatsapp: ["web.whatsapp.com"],
  grok: ["grok.x.ai"],
  chatgpt: ["chatgpt.com", "chat.openai.com"],
};

function sendNative(msg, timeoutMs = 6000) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (value) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      resolve(value);
    };
    const timer = setTimeout(() => {
      finish({ ok: false, error: "timeout native host", native: false });
    }, timeoutMs);

    try {
      chrome.runtime.sendNativeMessage(NATIVE_HOST, msg, (response) => {
        const err = chrome.runtime.lastError;
        if (err) {
          finish({
            ok: false,
            error: err.message || String(err),
            native: false,
          });
          return;
        }
        finish({ ...(response || { ok: false, error: "sem resposta" }), native: true });
      });
    } catch (e) {
      finish({ ok: false, error: String(e), native: false });
    }
  });
}

function matchAppFromUrl(url) {
  try {
    const host = new URL(url).hostname.replace(/^www\./, "");
    for (const [app, hosts] of Object.entries(APP_HOST_MATCH)) {
      if (hosts.some((h) => host === h || host.endsWith("." + h))) return app;
    }
  } catch (_) {
    /* ignore */
  }
  return null;
}

async function listAppTabs() {
  const tabs = await chrome.tabs.query({});
  const rows = [];
  for (const t of tabs) {
    if (!t.url || t.url.startsWith("chrome")) continue;
    const app = matchAppFromUrl(t.url);
    rows.push({
      id: t.id,
      title: (t.title || "").slice(0, 120),
      url: t.url,
      active: !!t.active,
      windowId: t.windowId,
      app: app || null,
    });
  }
  return rows;
}

async function findAppTab(app) {
  const hosts = APP_HOST_MATCH[app];
  if (!hosts) return null;
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) {
    if (!t.url) continue;
    try {
      const host = new URL(t.url).hostname.replace(/^www\./, "");
      if (hosts.some((h) => host === h || host.endsWith("." + h))) return t;
    } catch (_) {
      /* ignore */
    }
  }
  return null;
}

async function focusOrOpenApp(app) {
  const existing = await findAppTab(app);
  if (existing && existing.id != null) {
    await chrome.tabs.update(existing.id, { active: true });
    if (existing.windowId != null) {
      try {
        await chrome.windows.update(existing.windowId, { focused: true });
      } catch (_) {
        /* ignore */
      }
    }
    return {
      ok: true,
      data: {
        app,
        mode: "focus",
        tabId: existing.id,
        url: existing.url,
        title: existing.title,
      },
    };
  }

  const native = await sendNative({ type: "veu.host.openApp", app });
  if (native && native.ok) {
    return native;
  }

  const url = WEB_APPS[app];
  if (url) {
    const tab = await chrome.tabs.create({ url });
    return {
      ok: true,
      data: {
        opened: url,
        mode: "web-fallback",
        tabId: tab && tab.id,
        nativeError: native && native.error,
      },
    };
  }

  return {
    ok: false,
    error:
      (native && native.error ? `Native: ${native.error}. ` : "") +
      `App "${app}" precisa do host nativo.`,
  };
}

/** Scrapers rodam no contexto da aba (DOM). Heurísticos e tolerantes. */
function scrapeSurfaceFn(app) {
  const clean = (s) => String(s || "").replace(/\s+/g, " ").trim();
  const items = [];
  const push = (line) => {
    const t = clean(line);
    if (t && t.length > 2 && !items.includes(t)) items.push(t.slice(0, 220));
  };

  if (app === "gmail") {
    const rows = document.querySelectorAll("tr.zA, div[role='row']");
    rows.forEach((row) => {
      if (items.length >= 12) return;
      const text = clean(row.innerText || row.textContent);
      if (text && text.length > 8 && text.length < 400) push(text.slice(0, 200));
    });
  } else if (app === "outlook") {
    const rows = document.querySelectorAll(
      "[role='option'], [role='row'], div[class*='mailList'], div[class*='listItem']",
    );
    rows.forEach((row) => {
      if (items.length >= 12) return;
      const text = clean(row.innerText || row.textContent);
      if (text && text.length > 8 && text.length < 400) push(text.slice(0, 200));
    });
  } else if (app === "whatsapp") {
    const rows = document.querySelectorAll(
      "[data-testid='cell-frame-container'], div[role='listitem'], div[role='row']",
    );
    rows.forEach((row) => {
      if (items.length >= 12) return;
      const text = clean(row.innerText || row.textContent);
      if (text && text.length > 3 && text.length < 300) push(text.slice(0, 180));
    });
  } else if (app === "slack") {
    const rows = document.querySelectorAll(
      "[data-qa='message_content'], .c-message_kit__text, [role='listitem']",
    );
    rows.forEach((row) => {
      if (items.length >= 12) return;
      const text = clean(row.innerText || row.textContent);
      if (text && text.length > 3 && text.length < 400) push(text.slice(0, 200));
    });
  } else if (app === "teams") {
    const rows = document.querySelectorAll(
      "[data-tid='chat-pane-message'], [role='listitem'], [role='article']",
    );
    rows.forEach((row) => {
      if (items.length >= 12) return;
      const text = clean(row.innerText || row.textContent);
      if (text && text.length > 3 && text.length < 400) push(text.slice(0, 200));
    });
  } else {
    const main =
      document.querySelector("main, [role='main'], #app, body") || document.body;
    const text = clean(main && (main.innerText || main.textContent));
    if (text) {
      text
        .split("\n")
        .map(clean)
        .filter((l) => l.length > 12 && l.length < 200)
        .slice(0, 10)
        .forEach(push);
    }
  }

  return {
    app,
    url: location.href,
    title: document.title || "",
    count: items.length,
    items,
    note:
      items.length === 0
        ? "Nada legível na aba — faça login ou espere a página carregar e peça de novo."
        : undefined,
  };
}

async function readSurface(app) {
  let tab = await findAppTab(app);
  if (!tab) {
    const opened = await focusOrOpenApp(app);
    if (!opened.ok) return opened;
    // espera curta pra aba carregar
    await new Promise((r) => setTimeout(r, 1800));
    tab = await findAppTab(app);
  } else {
    await chrome.tabs.update(tab.id, { active: true });
  }
  if (!tab || tab.id == null) {
    return {
      ok: false,
      error: `Não achei aba do ${app}. Abra o app e peça de novo.`,
    };
  }

  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: scrapeSurfaceFn,
      args: [app],
    });
    const data = results && results[0] && results[0].result;
    if (!data) {
      return { ok: false, error: "Sem retorno do scrape na aba." };
    }
    return { ok: true, data };
  } catch (e) {
    return {
      ok: false,
      error:
        String(e && e.message ? e.message : e) +
        " — confira permissões da extensão nas abas do app.",
    };
  }
}

function formatSurfaceText(data) {
  if (!data) return "";
  const lines = [`${data.app || "app"} · ${data.title || data.url || ""}`];
  if (data.items && data.items.length) {
    data.items.forEach((it, i) => lines.push(`${i + 1}. ${it}`));
  } else if (data.note) {
    lines.push(data.note);
  }
  return lines.join("\n");
}

chrome.runtime.onInstalled.addListener(() => {
  console.info(`[Véu Host ${VERSION}] instalada · native=${NATIVE_HOST}`);
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || !msg.type) {
    sendResponse({ ok: false, error: "mensagem inválida" });
    return false;
  }

  (async () => {
    if (msg.type === "veu.host.info" || msg.type === "veu.ping") {
      const native = await sendNative({ type: "veu.host.info" }, 2500);
      sendResponse({
        ok: true,
        data: {
          version: VERSION,
          extensionId: chrome.runtime.id,
          nativeHost: NATIVE_HOST,
          nativeConnected: !!(native && native.ok && native.native),
          nativeError: native && !native.ok ? native.error : undefined,
          nativeData: native && native.ok ? native.data : undefined,
          capabilities: [
            "ping",
            "openApp",
            "focusApp",
            "listTabs",
            "readSurface",
            "shell",
            "fs",
            "runPreset",
          ],
          note:
            native && native.ok
              ? "extensão + Native Messaging ok"
              : "extensão ok — instale o host nativo para terminal/shell",
        },
      });
      return;
    }

    if (msg.type === "veu.host.openUrl") {
      const url = String(msg.url || "").trim();
      if (!url || !/^https?:\/\//i.test(url)) {
        sendResponse({ ok: false, error: "URL inválida" });
        return;
      }
      await chrome.tabs.create({ url });
      sendResponse({ ok: true, data: { opened: url, mode: "tab" } });
      return;
    }

    if (msg.type === "veu.host.openApp" || msg.type === "veu.host.focusApp") {
      const app = String(msg.app || "").trim().toLowerCase();
      if (!app) {
        sendResponse({ ok: false, error: "app vazio" });
        return;
      }
      // web apps: foca aba existente; nativos (terminal) via native
      if (WEB_APPS[app] || APP_HOST_MATCH[app]) {
        sendResponse(await focusOrOpenApp(app));
        return;
      }
      const native = await sendNative({ type: "veu.host.openApp", app });
      if (native && native.ok) {
        sendResponse(native);
        return;
      }
      sendResponse({
        ok: false,
        error:
          (native && native.error ? `Native: ${native.error}. ` : "") +
          `App "${app}" precisa do host nativo. ` +
          `Instale: /extension/native/ (ID ${chrome.runtime.id})`,
        data: {
          extensionId: chrome.runtime.id,
          nativeHost: NATIVE_HOST,
          install: "https://veu.ch8ai.com.br/extension/#native",
        },
      });
      return;
    }

    if (msg.type === "veu.host.listTabs") {
      const tabs = await listAppTabs();
      const known = tabs.filter((t) => t.app);
      sendResponse({
        ok: true,
        data: {
          total: tabs.length,
          known: known.length,
          tabs: known.length ? known : tabs.slice(0, 40),
          text:
            (known.length ? known : tabs.slice(0, 20))
              .map(
                (t, i) =>
                  `${i + 1}. ${t.app ? `[${t.app}] ` : ""}${(t.title || t.url || "").slice(0, 100)}`,
              )
              .join("\n") || "Nenhuma aba encontrada.",
        },
      });
      return;
    }

    if (msg.type === "veu.host.readSurface") {
      const app = String(msg.app || "").trim().toLowerCase();
      if (!app) {
        sendResponse({ ok: false, error: "app vazio" });
        return;
      }
      const result = await readSurface(app);
      if (result.ok && result.data) {
        result.data.text = formatSurfaceText(result.data);
      }
      sendResponse(result);
      return;
    }

    if (msg.type === "veu.host.runPreset") {
      const preset = String(msg.preset || "").trim();
      const native = await sendNative({ type: "veu.host.runPreset", preset });
      if (native && native.ok) {
        sendResponse(native);
        return;
      }
      const url = WEB_APPS[preset];
      if (url) {
        await chrome.tabs.create({ url });
        sendResponse({
          ok: true,
          data: { opened: url, mode: "web-fallback", preset },
        });
        return;
      }
      sendResponse({
        ok: false,
        error:
          (native && native.error) ||
          "Host nativo ausente para este preset. Instale /extension/native/",
        data: { extensionId: chrome.runtime.id },
      });
      return;
    }

    if (
      msg.type === "veu.host.shell" ||
      msg.type === "veu.host.readPath" ||
      msg.type === "veu.host.listDir"
    ) {
      const native = await sendNative(msg);
      sendResponse(
        native && native.ok
          ? native
          : {
              ok: false,
              error:
                (native && native.error) ||
                "Host nativo ausente. Rode install.sh / install.ps1 em /extension/native/",
              data: { extensionId: chrome.runtime.id },
            },
      );
      return;
    }

    sendResponse({ ok: false, error: `tipo não suportado: ${msg.type}` });
  })();

  return true;
});
