# Véu Host 0.2.0

Liga **https://veu.ch8ai.com.br** à máquina física (Chrome / Edge).

## Instalar

1. Baixe a pasta (ou use a do servidor: `/root/veu/extension`)
2. `chrome://extensions` → **Modo do desenvolvedor**
3. **Carregar sem compactação** → selecione esta pasta
4. Confira a versão **0.2.0**
5. Abra https://veu.ch8ai.com.br e dê **F5**
6. Topo do SO: `host · ok`

Também em: https://veu.ch8ai.com.br/extension/

## Se não detectar

- Remova a extensão antiga e carregue de novo esta pasta **0.2.0**
- Use a URL `https://veu.ch8ai.com.br` (não só o IP, se puder)
- Clique **Recarregar** na extensão e F5 na aba
