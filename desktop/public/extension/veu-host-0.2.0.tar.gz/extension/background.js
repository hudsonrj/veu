/**
 * Véu Host 0.2.0 — service worker (stub nativo).
 * Native Messaging (shell/fs reais) entra depois.
 */

const VERSION = "0.2.0";

const WEB_APPS = {
  whatsapp: "https://web.whatsapp.com/",
  gmail: "https://mail.google.com/",
  notion: "https://www.notion.so/",
  teams: "https://teams.microsoft.com/",
  outlook: "https://outlook.office.com/",
  slack: "https://app.slack.com/",
};

chrome.runtime.onInstalled.addListener(() => {
  console.info(`[Véu Host ${VERSION}] instalada`);
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || !msg.type) {
    sendResponse({ ok: false, error: "mensagem inválida" });
    return false;
  }

  (async () => {
    if (msg.type === "veu.host.info" || msg.type === "veu.ping") {
      sendResponse({
        ok: true,
        data: {
          version: VERSION,
          note: "ping/info ok — Native Messaging ainda não ligado",
        },
      });
      return;
    }

    if (msg.type === "veu.host.openApp") {
      const url = WEB_APPS[msg.app];
      if (url) {
        await chrome.tabs.create({ url });
        sendResponse({ ok: true, data: { opened: url, mode: "web-fallback" } });
      } else {
        sendResponse({
          ok: false,
          error: `App "${msg.app}" exige Native Messaging (ainda não instalado)`,
        });
      }
      return;
    }

    if (
      msg.type === "veu.host.shell" ||
      msg.type === "veu.host.readPath" ||
      msg.type === "veu.host.listDir"
    ) {
      sendResponse({
        ok: false,
        error: "Requer host nativo (Native Messaging). Extensão presente.",
      });
      return;
    }

    sendResponse({ ok: false, error: `tipo não suportado: ${msg.type}` });
  })();

  return true;
});
