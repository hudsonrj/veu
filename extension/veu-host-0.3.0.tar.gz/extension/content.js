/**
 * Véu Host 0.3.0 — ponte página ↔ extensão.
 * Canal: window.postMessage { source: "veu-os" | "veu-extension" }
 */
(() => {
  const EXT = "veu-extension";
  const OS = "veu-os";
  const VERSION = "0.3.0";

  const platform = (() => {
    try {
      const p = navigator.userAgentData && navigator.userAgentData.platform;
      if (p) return String(p).toLowerCase().includes("win")
        ? "win32"
        : String(p).toLowerCase().includes("mac")
          ? "darwin"
          : String(p).toLowerCase().includes("linux")
            ? "linux"
            : String(p);
    } catch (_) {
      /* ignore */
    }
    const ua = navigator.userAgent || "";
    if (/Windows/i.test(ua)) return "win32";
    if (/Linux/i.test(ua)) return "linux";
    if (/Mac/i.test(ua)) return "darwin";
    return "unknown";
  })();

  const caps = ["ping", "openApp", "shell", "fs"];

  const post = (payload) => {
    window.postMessage({ source: EXT, version: VERSION, platform, capabilities: caps, ...payload }, "*");
  };

  const announce = () => {
    post({ type: "veu.ready", ok: true });
  };

  window.addEventListener("message", (ev) => {
    if (ev.source !== window) return;
    const msg = ev.data;
    if (!msg || msg.source !== OS || typeof msg.type !== "string") return;

    const replyTo = msg.id;

    if (msg.type === "veu.ping") {
      post({ type: "veu.pong", ok: true, replyTo });
      return;
    }

    if (msg.type === "veu.host.info") {
      post({
        type: "veu.host.info.result",
        ok: true,
        replyTo,
        data: {
          version: VERSION,
          platform,
          capabilities: caps,
          host: location.host,
          userAgent: navigator.userAgent,
        },
      });
      return;
    }

    // Demais pedidos → service worker
    try {
      if (!chrome?.runtime?.sendMessage) {
        post({
          type: `${msg.type}.result`,
          ok: false,
          replyTo,
          error: "runtime indisponível",
        });
        return;
      }
      chrome.runtime.sendMessage(msg, (res) => {
        const err = chrome.runtime.lastError;
        if (err) {
          post({
            type: `${msg.type}.result`,
            ok: false,
            replyTo,
            error: err.message || String(err),
          });
          return;
        }
        post({
          type: `${msg.type}.result`,
          ok: !!(res && res.ok),
          replyTo,
          data: res && res.data,
          error: res && res.error,
        });
      });
    } catch (e) {
      post({
        type: `${msg.type}.result`,
        ok: false,
        replyTo,
        error: String(e && e.message ? e.message : e),
      });
    }
  });

  announce();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", announce, { once: true });
  } else {
    setTimeout(announce, 0);
  }
  window.addEventListener("load", announce, { once: true });
  // Reanuncia a cada 8s enquanto a aba viver — cobre remount do React
  setInterval(announce, 8000);
})();
