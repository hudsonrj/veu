# Instala Native Messaging host com.veu.host (Windows)
param(
  [Parameter(Mandatory = $true)]
  [string]$ExtensionId
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$HostPy = Join-Path $Root "veu_host.py"
$Launcher = Join-Path $Root "veu_host_launcher.bat"

# Launcher: prefere python, senão py launcher
@"
@echo off
where python >nul 2>&1 && (
  python -u "%~dp0veu_host.py"
  exit /b %ERRORLEVEL%
)
where py >nul 2>&1 && (
  py -3 -u "%~dp0veu_host.py"
  exit /b %ERRORLEVEL%
)
echo Veu host: Python 3 nao encontrado >&2
exit /b 1
"@ | Set-Content -Path $Launcher -Encoding ASCII

if (-not (Get-Command python -ErrorAction SilentlyContinue) -and -not (Get-Command py -ErrorAction SilentlyContinue)) {
  Write-Host "Instale Python 3 (https://python.org) e marque Add to PATH, depois rode de novo."
  exit 1
}

$ManifestDir = Join-Path $env:LOCALAPPDATA "veu\NativeMessagingHosts"
New-Item -ItemType Directory -Force -Path $ManifestDir | Out-Null
$ManifestPath = Join-Path $ManifestDir "com.veu.host.json"

$LauncherEscaped = $Launcher.Replace('\', '\\')
$manifest = @"
{
  "name": "com.veu.host",
  "description": "Veu Native Host",
  "path": "$LauncherEscaped",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://$ExtensionId/"
  ]
}
"@
Set-Content -Path $ManifestPath -Value $manifest -Encoding UTF8

# Registro Chrome + Edge
$keys = @(
  "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.veu.host",
  "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\com.veu.host"
)
foreach ($key in $keys) {
  New-Item -Path $key -Force | Out-Null
  New-ItemProperty -Path $key -Name "(default)" -Value $ManifestPath -Force | Out-Null
  Write-Host "ok → $key"
}

Write-Host ""
Write-Host "Pronto. Recarregue a extensao Veu Host e teste abrir terminal."
Write-Host "Manifest: $ManifestPath"
