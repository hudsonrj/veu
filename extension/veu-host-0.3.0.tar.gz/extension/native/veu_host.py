#!/usr/bin/env python3
"""Véu Native Messaging host — com.veu.host

Lê mensagens length-prefixed (Chrome) e abre apps / shell básico.
"""
from __future__ import annotations

import json
import os
import struct
import subprocess
import sys
from pathlib import Path


def read_msg() -> dict | None:
    raw = sys.stdin.buffer.read(4)
    if not raw or len(raw) < 4:
        return None
    (n,) = struct.unpack("<I", raw)
    data = sys.stdin.buffer.read(n)
    if not data:
        return None
    return json.loads(data.decode("utf-8"))


def write_msg(msg: dict) -> None:
    blob = json.dumps(msg, ensure_ascii=False).encode("utf-8")
    sys.stdout.buffer.write(struct.pack("<I", len(blob)))
    sys.stdout.buffer.write(blob)
    sys.stdout.buffer.flush()


def open_terminal() -> dict:
    if sys.platform.startswith("win"):
        for cmd in (
            ["wt.exe"],
            ["powershell.exe", "-NoExit"],
            ["cmd.exe"],
        ):
            try:
                subprocess.Popen(
                    cmd,
                    close_fds=True,
                    creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0),
                )
                return {"ok": True, "data": {"opened": cmd[0], "mode": "native"}}
            except FileNotFoundError:
                continue
        return {"ok": False, "error": "nenhum terminal encontrado (wt/powershell/cmd)"}

    # Linux / macOS
    candidates = [
        ["x-terminal-emulator"],
        ["gnome-terminal"],
        ["konsole"],
        ["xfce4-terminal"],
        ["alacritty"],
        ["kitty"],
        ["xterm"],
        ["open", "-a", "Terminal"],  # macOS
    ]
    for cmd in candidates:
        try:
            subprocess.Popen(cmd, start_new_session=True)
            return {"ok": True, "data": {"opened": " ".join(cmd), "mode": "native"}}
        except FileNotFoundError:
            continue
    return {"ok": False, "error": "nenhum emulador de terminal encontrado"}


def open_app(app: str) -> dict:
    app = (app or "").lower().strip()
    if app in ("terminal", "shell", "console"):
        return open_terminal()

    urls = {
        "whatsapp": "https://web.whatsapp.com/",
        "gmail": "https://mail.google.com/",
        "notion": "https://www.notion.so/",
        "teams": "https://teams.microsoft.com/",
        "outlook": "https://outlook.office.com/",
        "slack": "https://app.slack.com/",
    }
    url = urls.get(app)
    if url:
        if sys.platform.startswith("win"):
            os.startfile(url)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", url])
        else:
            subprocess.Popen(["xdg-open", url])
        return {"ok": True, "data": {"opened": url, "mode": "native-url"}}

    return {"ok": False, "error": f'app desconhecido: "{app}"'}


def run_shell(command: str, cwd: str | None = None) -> dict:
    if not command or not command.strip():
        return {"ok": False, "error": "command vazio"}
    # Conservador: só permite se VEU_HOST_ALLOW_SHELL=1
    if os.environ.get("VEU_HOST_ALLOW_SHELL") != "1":
        return {
            "ok": False,
            "error": "shell desabilitado — exporte VEU_HOST_ALLOW_SHELL=1 no host",
        }
    try:
        proc = subprocess.run(
            command,
            shell=True,
            cwd=cwd or None,
            capture_output=True,
            text=True,
            timeout=30,
        )
        return {
            "ok": proc.returncode == 0,
            "data": {
                "code": proc.returncode,
                "stdout": (proc.stdout or "")[:8000],
                "stderr": (proc.stderr or "")[:4000],
            },
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def main() -> int:
    while True:
        msg = read_msg()
        if msg is None:
            return 0
        typ = msg.get("type") or ""
        if typ in ("veu.host.info", "veu.ping", "ping"):
            write_msg(
                {
                    "ok": True,
                    "data": {
                        "version": "0.3.0",
                        "native": True,
                        "platform": sys.platform,
                        "host": str(Path(__file__).resolve()),
                    },
                }
            )
        elif typ == "veu.host.openApp":
            write_msg(open_app(str(msg.get("app") or "")))
        elif typ == "veu.host.shell":
            write_msg(run_shell(str(msg.get("command") or ""), msg.get("cwd")))
        else:
            write_msg({"ok": False, "error": f"tipo não suportado: {typ}"})
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BrokenPipeError:
        raise SystemExit(0)
